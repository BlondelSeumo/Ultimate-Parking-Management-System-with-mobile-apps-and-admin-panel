import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.page.html',
  styleUrls: ['./forgot.page.scss'],
})
export class ForgotPage implements OnInit {

  constructor(private ntrl:NavController) { }

  ngOnInit() {
  }
  backPage(){
    this.ntrl.back();
  }
  signIn(){
    this.ntrl.navigateForward(['login']);
  }
}
